<div class="content-page">
	<!-- Start content -->
	<div class="content">
		<div class="container-fluid">
			<div class="page-title-box">
				<div class="row align-items-center">
					<div class="col-sm-6">
						<h4 class="page-title">Dashboard</h4>
						<ol class="breadcrumb">
						</ol>

					</div>
					<div class="col-sm-6">

					</div>
				</div>
</div>
		</div>

</div>

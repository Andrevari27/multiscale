<footer class="footer">
    © 2024 <span class="d-none d-sm-inline-block"></span>.
</footer>

<script>
$(document).ready(function() {
    $('.data').DataTable();
});
</script>
</script>
<!-- jQuery  -->
<script src="<?= base_url() ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() ?>assets/js/metisMenu.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.slimscroll.js"></script>
<script src="<?= base_url() ?>assets/js/waves.min.js"></script>

<!-- Required datatable js -->
<script src="<?= base_url() ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>

<!--Chartist Chart-->
<script src="<?= base_url() ?>assets/plugins/chartist/js/chartist.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/chartist/js/chartist-plugin-tooltip.min.js"></script>

<!-- Buttons examples -->
<script src="<?= base_url() ?>assets/plugins/datatables/dataTables.buttons.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/jszip.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/pdfmake.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/vfs_fonts.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/buttons.html5.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/buttons.print.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/buttons.colVis.min.js"></script>

<!-- Responsive examples -->
<script src="<?= base_url() ?>assets/plugins/datatables/dataTables.responsive.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

<!-- Datatable init js -->
<script src="<?= base_url() ?>assets/pages/datatables.init.js"></script>



<!-- peity JS -->
<script src="<?= base_url() ?>assets/plugins/peity-chart/jquery.peity.min.js"></script>

<script src="<?= base_url() ?>assets/pages/dashboard.js"></script>

<!-- App js -->
<script src="<?= base_url() ?>assets/js/app.js"></script>

</body>

</html>
<div class="row">
	<div class="col-md-12">
		
	
	<div class="card card-primary">
		<div class="card-header">
			<div class="col-md-12">
			<h3 class="float-left">Data Penduduk RT 03. RW 04</h3>
			<button class="btn btn-sm btn-primary float-right"><i class="fa fa-plus"></i> Penduduk Baru</button> 
			</div>
		</div>
		<div class="card-body">
			<table id="example" class="table table-striped table-bordered table-hover" style="width:100%">
				<thead>
					<tr>
						<th>A</th>
						<th>A</th>
						<th>A</th>
					</tr>
				</thead>
				<tbody>
					<td>A</td>
					<td>A</td>
					<td>A</td>
				</tbody>
			</table>
		</div>
	</div>

	</div>
</div>